# Clock, main task

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### PROPS
```
      glow:'',
      serverDate: date,
      simpleTime: boolean,
      simpleDate: boolean,
      simpleDateTime: boolean,
      advancedTime: boolean,
```

### HOW TO USE
```
glow =  for glow fx
serverdate = pass server time for comparison to client time.

DATETIME FORMAT 

Simple {
    time
    date
    datetime
}
Advanced Time :

```